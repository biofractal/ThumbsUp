﻿using Nancy.Helper;
using System;
using System.Diagnostics;
using C = System.Console;

namespace ThumbsUp.UnitTests
{
	public class Program
	{
		[STAThread]
		public static void Main(string[] args)
		{
			Process.Start(new ProcessStartInfo { FileName = "..\\..\\..\\ThumbsUp.Service\\bin\\release\\ThumbsUp.exe" });

			C.WriteLine();
			C.WriteLine("Running ThumbsUp Unit Tests");
			C.WriteLine();

			CheckServiceIsRunning();
			RegisterNewApplication();
			RegisterExistingApplication();
			RegisterUser();
			UserLogin();
			UserFromKey();
			UserLogout();
			ValidateKey();
			ValidateUserName();
			GetErrorMessage();
			UserResetPassword();
			ForgotPasswordRequest();
			ForgotPasswordReset();

		}

		public static void CheckServiceIsRunning()
		{
			ProcessResult("CheckServiceIsRunning", ThumbsUpApi.CheckServiceIsRunning());
		}
		public static void RegisterNewApplication()
		{
			var name = C.ReadLine();
			ProcessResult("RegisterNewApplication", ThumbsUpApi.RegisterNewApplication(name));
		}
		public static void RegisterExistingApplication()
		{
			var name = C.ReadLine();
			var applicationId = C.ReadLine();
			ProcessResult("RegisterExistingApplication", ThumbsUpApi.RegisterExistingApplication(name, applicationId));
		}
		public static void UserLogin()
		{
			var username = "biofractal";
			var password = "r%7DF2a_/S5j";
			ProcessResult("UserLogin", ThumbsUpApi.ValidateUser(username, password));
		}

		public static void UserLogout()
		{
			var thumbKey = GetThumbKey();
			ProcessResult("UserLogout", ThumbsUpApi.Logout(thumbKey));
		}

		private static Guid GetThumbKey()
		{
			return Guid.NewGuid();
		}

		public static void RegisterUser()
		{
			var username = C.ReadLine();
			var email = C.ReadLine();
			ProcessResult("RegisterUser", ThumbsUpApi.CreateUser(username, email));
		}


		public static void UserFromKey()
		{
			var thumbKey = GetThumbKey();
			ProcessResult("UserFromKey", ThumbsUpApi.GetUserFromIdentifier(thumbKey));
		}

		public static void ValidateKey()
		{
			var thumbKey = GetThumbKey();
			ProcessResult("ValidateKey", ThumbsUpApi.ValidateKey(thumbKey));
		}

		public static void ValidateUserName()
		{
			var username = C.ReadLine();
			ProcessResult("ValidateUserName", ThumbsUpApi.ValidateUserName(username));
		}

		public static void GetErrorMessage()
		{
			var errorCode = C.ReadLine();
			ProcessResult("GetErrorMessage", ThumbsUpApi.GetErrorMessage(int.Parse(errorCode)));
		}

		public static void UserResetPassword()
		{
			var username = C.ReadLine();
			var password = C.ReadLine();
			ProcessResult("UserResetPassword", ThumbsUpApi.ResetPassword(username, password));
		}

		public static void ForgotPasswordRequest()
		{
			var username = C.ReadLine();
			var email = C.ReadLine();
			ProcessResult("ForgotPasswordRequest", ThumbsUpApi.ForgotPasswordRequest(username, email));
		}

		public static void ForgotPasswordReset()
		{
			var username = C.ReadLine();
			var token = C.ReadLine();
			ProcessResult("ForgotPasswordReset", ThumbsUpApi.ForgotPasswordReset(username, token));

		}

		private static void ProcessResult(string test, ThumbsUpApi.ThumbsUpResult result)
		{
			if (result.Success)
			{
				Console.ForegroundColor = ConsoleColor.Green;
				C.WriteLine("Passed : " + test);
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				C.WriteLine("Failed : " + test);
				C.WriteLine(result.Data.ErrorMessage);
			}
			Console.ResetColor();

		}
	}
}
